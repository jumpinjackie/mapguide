Selenium.version = "0.8.2";
Selenium.revision = "1727";

window.top.document.title += " v" + Selenium.version + " [" + Selenium.revision + "]";

