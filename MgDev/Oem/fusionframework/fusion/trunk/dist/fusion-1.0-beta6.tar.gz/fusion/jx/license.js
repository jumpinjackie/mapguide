/******************************************************************************
 *  Prototype JavaScript framework, version 1.5.0
 *  (c) 2005-2007 Sam Stephenson
 *  Prototype is freely distributable under the terms of an MIT-style license.
 *  For details, see the Prototype web site: http://prototype.conio.net/
 ******************************************************************************
 * Jx UI Library, version 1.0
 * Copyright (c) 2005, DM Solutions Group Inc.
 * Jx is freely distributable under the terms of an MIT-style license.
 *****************************************************************************/
