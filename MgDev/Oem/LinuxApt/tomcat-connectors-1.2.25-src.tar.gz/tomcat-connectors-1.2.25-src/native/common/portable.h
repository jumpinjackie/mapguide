/* On most platform this file is overwritten when doing configure */
/* DON'T COMMIT THE FILE IT BREAKS windoze and Netware, commit the sample file */
